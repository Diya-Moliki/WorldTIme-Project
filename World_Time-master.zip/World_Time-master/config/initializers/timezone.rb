require 'timezone'
Timezone::Configure.begin do |c|
  c.username = 'motolanilagoke@yahoo.com'
end